-- A way for including libraries cleanly
--
-- package.path = table.concat({
--   _USERHOME..'/ta-tweaks/?.lua',
--   package.path
-- }, ';');
-- require('project')

common = require("common")
snip   = require("snip")
extra  = require("extra")

local _spellcheck_module = _USERHOME..'/modules/spellcheck/'
if lfs.attributes(_spellcheck_module) then
   _M.spellcheck = require("spellcheck")
end

local _spellcheck_module = OSX and 'file_diff' or 'filediff'
local _spellcheck_dir = _USERHOME..'/modules/'.._spellcheck_module
if lfs.attributes(_spellcheck_dir) then
   _M.filediff = require(_spellcheck_module)
end

local keys=keys
local M={}

-- local ftheme, crf = 'light',  0xffffff
local ftheme, crf = 'emacs',  0xffff00
-- local ftheme, crf = 'base16-materia',  0x00ffff

if CURSES then
   view:set_theme('term')
else
   -- view:set_theme(ftheme)
   -- view:set_theme(ftheme,{font='Ubuntu Mono', size=13})
   view:set_theme(ftheme,{font='Monaco', size=11})
   if not LINUX then
      view.extra_ascent = 1
      view.extra_descent = 2
   end
   view.caret_width = 2
   view.caret_fore = crf
end

--
-- This will help score better at pylint ;-)
--
textadept.editing.strip_trailing_spaces = true
--
-- Paste reindent annoys me a lot!
--
textadept.editing.paste_reindents = false
textadept.editing.AUTOCOMPLETE_ALL = true
--
textadept.file_types.patterns['^#!.+[/ ]tcc'] = 'cpp'
textadept.file_types.patterns['^#!.+[/ ]make'] = 'makefile'
textadept.file_types.patterns['^#!.+ JavaScript'] = 'javascript'

-- Cloud Config is YAML
--
textadept.file_types.patterns['^#cloud%-config'] = 'yaml'

-- TODO: Scapy unit test scripts are only Python-ish. Use lexer but don't check
--
-- textadept.file_types.extensions['uts'] = 'python'

textadept.file_types.extensions.changelog = 'changelog'
textadept.file_types.extensions.bash_aliases = 'bash'
textadept.file_types.extensions.bash_profile = 'bash'

-- P4_16
--
textadept.file_types.extensions.p4 = 'p4'
-- textadept.file_types.patterns['^.+ P4_16'] = 'p4'

-- YANG
--
textadept.file_types.extensions.yang = 'yang'

-- Migrating longer snippets to snippet files
--
local _lexer_snippets = _USERHOME..'/snippets/'
if lfs.attributes(_lexer_snippets) then
   textadept.snippets.paths = { _lexer_snippets }
end

local tabsize = {
   ansi_c =     { true, 4 },
   bash =       { false, 2 },
   bibtex =     { false, 2 },
   changelog =  { false, 2 },
   cpp =        { true, 4 },
   diff =       { true,  8 },
   go =         { false, 2 },
   ini =        { false, 4 },
   java =       { false, 4 },
   javascript = { false, 2 },
   latex =      { false, 2 },
   lua =        { false, 3 },
   makefile =   { true, 8 },
   markdown =   { false, 2 },
   python =     { false, 4 },
   text =       { true, 8 },
   xml =        { false, 2 },
   yaml =       { false, 2 },
   yang =       { false, 4 },
}

-- default is view.WRAP_NONE

local wrapmode = {
   bibtex = view.WRAP_WHITESPACE,
   latex = view.WRAP_WHITESPACE,
   text = view.WRAP_WHITESPACE,
   xml = view.WRAP_WHITESPACE ,
   yang = view.WRAP_WHITESPACE,
}

-- semantic highlighting. NEED base16 themes to work!
-- enable semantic highlighting
--

events.connect(events.LEXER_LOADED, function(lexer)

   if tabsize[lexer] ~= nil then
      view.use_tabs = tabsize[lexer][1]
      view.tab_width = tabsize[lexer][2]
   end

   if wrapmode[lexer] ~= nil then
      view.wrap_mode = wrapmode[lexer]
      view.wrap_visual_flags = view.WRAPVISUALFLAG_MARGIN
   else
      view.wrap_mode = view.WRAP_NONE
      view.wrap_visual_flags = view.WRAPVISUALFLAG_NONE
   end

end)

events.connect(events.INITIALIZED, function()
   if CURSES then return end
   ui.size = OSX and {800,600} or {900, 535} -- width, height
end)

-- Keys
--
-- Save file and reset Lua state
keys['ctrl+esc'] = function()
   io.save_all_files()
   reset()
end
--
-- insert date
keys['ctrl+D'] = function() return common.insert_date("%a, %d %b %Y %H:%m:%S %z") end
--
-- Alternative for block comment
keys['ctrl+;'] = function() return textadept.editing.toggle_comment() end
--
-- Undo like emacs
keys['ctrl+_'] = function() return _G.buffer:undo() end
--
-- Autocomplete
keys['ctrl+\t'] = function() textadept.editing.autocomplete('word') end


-- Debug key strokes
--
-- events.connect(events.KEYPRESS, function(code)
--   ui.statusbar_text = code
-- end)

--
-- This is to avoid the Alt.Shift problem in multilang keyboards in GNOME3/Linux
--
if LINUX then
   keys['ctrl+down']  = view.line_down_rect_extend
   keys['ctrl+up']    = view.line_up_rect_extend
   keys['ctrl+left']  = view.char_left_rect_extend
   keys['ctrl+right'] = view.char_right_rect_extend
end

if OSX then
   cmd='osascript -l JavaScript -e \'Application("System Events").processes["textadept"].frontmost=true\''
   f=io.popen(cmd)
   f:read()
end
