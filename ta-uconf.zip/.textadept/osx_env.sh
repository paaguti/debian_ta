export PATH=$PATH
export PWD=`pwd`
