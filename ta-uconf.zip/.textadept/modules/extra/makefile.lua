--- lua extensions
-- @module makefile
--

common = require("common")

local function connecting()
   common.key_pairing(false, '<',  '>')
   common.key_pairing(false, '[',  ']')
   common.key_pairing(false, '`', '`')
   common.key_pairing(false, '{',  '}')
   common.key_pairing(true,  '"',  '"')
   common.key_pairing(true,  '\'', '\'')
   common.key_pairing(true,  '(',  ')')
end

---
-- Key bindings
--
local binding= {
   ['(']  = function() return common.enclose_keys('(', ')') end,
   ['"']  = function() return common.enclose_keys('"', '"') end,
   ['\''] = function() return common.enclose_keys('\'', '\'') end
}

---
-- Snippets.
--
local snipping = {
   -- true,
   -- 'make rebuild' is normally a 'make clean all'
   rb = 'rebuild:\t%1(clean) all\n\n',
   all = 'all:\t%1(target)\n\n',
   tools = 'CC=%1(gcc)\nCFLAGS += %2(-std=gnu99)\nLD=%1\n',
}

return {
	connecting = connecting,
	snipping   = snipping,
	binding    = binding
}
