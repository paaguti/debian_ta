--- lua extensions
-- @module lua
--

common = require("common")

local function connecting()
   common.key_pairing(true,  '<',  '>')
   common.key_pairing(false, '{',  '}')
   common.key_pairing(false, '[',  ']')
   common.key_pairing(false, '(',  ')')
   common.key_pairing(false, '"',  '"')
   common.key_pairing(false, '\'', '\'')
   common.key_pairing(false, '`', '`')
end


local snipping = {
   -- true,
   tag = '<%1(tag)>%<selected_text>%0</%1>',
   tagc = '<%1(tag) class="%2(class)">%<selected_text>%0</%1>',
   tagn = '<%1(tag) />',
   th= '<th>%<selected_text>%0</th>',
   hd= '<h%1(1)>%<selected_text>%0</h%1>',
}

local binding = {
   ['<']       = function() return common.enclose_keys('<',  '>') end,
   ['ctrl+H']  = function() return textadept.snippets._insert(snipping['hd']) end,
   ['ctrl+T']  = function() return textadept.snippets._insert(snipping['tag']) end,
   ['ctrl+C']  = function() return textadept.snippets._insert(snipping['tagc']) end,
   ['ctrl+/']  = function() return textadept.snippets._insert(snipping['tagn']) end,
}

return {
   connecting = connecting,
   snipping   = snipping,
   binding    = binding,
}
