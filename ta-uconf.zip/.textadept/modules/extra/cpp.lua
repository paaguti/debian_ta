common = require("common")

local function connecting()
   common.key_pairing(false, '<',  '>')
   common.key_pairing(true,  '{',  '}')
   common.key_pairing(true,  '[',  ']')
   common.key_pairing(true,  '(',  ')')
   common.key_pairing(true,  '"',  '"')
   common.key_pairing(true,  '\'', '\'')
   common.key_pairing(false, '`', '`')
end

local snipping = {
   -- true,
   ['attr'] = '__attribute__((%1(unused)))%0',
   ['inc']  = '#include <%1(header).h>\n%0',
   ['incl'] = '#include "%1(header).h"\n%0',
   ['main'] = 'int main(int argc,char **argv)\n{\n\t%0\n}\n',
   ['hdef'] = '#ifndef %1(__SYM_)\n# define %1\n%0\n#endif // %1\n',
}

return {
   connecting = connecting,
   binding = nil,
   snipping   = snipping,
}
