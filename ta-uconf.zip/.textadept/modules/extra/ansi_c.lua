common = require("common")

local function connecting()
   common.key_pairing(false, '<',  '>')
   common.key_pairing(true,  '{',  '}')
   common.key_pairing(true,  '[',  ']')
   common.key_pairing(true,  '(',  ')')
   common.key_pairing(true,  '"',  '"')
   common.key_pairing(true,  '\'', '\'')
   common.key_pairing(false, '`', '`')
end

local snipping = {
   -- true,
   ['main'] = 'int main(int argc,char **argv)\n{\t%1\n}\n',
   ['inc'] = '#include <%1(header).h>\n',
   ['incl'] = '#include "%1(header).h"\n',
   ['ap'] = '__attribute__((__packed__))%0',
   ['au'] = '__attribute__((__unused__))%0',
   ['vu'] = '(void)%1;\n%0',
   ['fn'] ='%1(void function)(%2(void))\n{\n\t%0\n}\n',
   ['sfn'] ='static\n%1(void function)(%2(void))\n{\n\t%0\n}\n',
   ['sifn'] ='static inline\n%1(void function)(%2(void))\n{\n\t%0\n}\n',
   ['ifdef'] ='#infdef %1(__HEADER__)\n# define %1\n%0\n#endif /* %1 */\n',
}

local binding = {
   ['(']   = function() return common.enclose_keys('(',  ')') end,
   ['[']   = function() return common.enclose_keys('[',  ']') end,
   ['"']   = function() return common.enclose_keys('"',  '"') end,
   ['\'']  = function() return common.enclose_keys('\'', '\'') end,
   ['{']   = function() return common.enclose_keys('{',  '}') end,
}

return {
   connecting = connecting,
   snipping   = snipping,
   binding    = binding
}
