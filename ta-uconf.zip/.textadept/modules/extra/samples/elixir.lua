--- extends elixir.
-- @author [Alejandro Baez](https://twitter.com/a_baez)
-- @coypright 2016
-- @license MIT (see LICENSE)
-- @module elixir

local snipping = {
  true,

  -- def
  d = "def%1{,impl,module,protocol,struct,exception}",
  def = "def%1{,p} %2(name)(%3(arguments)) do",
  defexception = "defexception %1(message)",
  err = "defexception %1(message)",
  defimpl = "defimpl %1(Protocol), for: %2(Type) do",
  impl = "defimpl %1(Protocol), for: %2(Type) do",
  defprotocol = "defprotocol %1(Protocol) do",
  pro = "defprotocol %1(Protocol) do",
  defmodule = "defmodule %1(name) do",
  mod = "defmodule %1(name) do",
  struct = "defstruct [%1(param)]",
  defstruct = "defstruct [%1(param)]",

  -- case, loop
  c = "%1{cond,case}%0",
  case = "case %1(pattern) do",
  cond = "cond %1(pattern) do",
  ["for"] = "for %1(<-) do",
  try = "try do\n\t%1(body)\n%2{rescue,catch,after}\nend",
  rescue = "rescue\n\t->",
  catch = "catch\n\t->",
  after = "after\n\t->",

  -- random
  ["do"] = "do\n\t%0\nend",
  fn = "fn%1((%2(param))) -> %3(body) end",
  rec = "receive do\n\t%3(body)\n%1(after\n\t%2(timeout))\nend",
  ["->"] = "%1(pattn) -> ",
  ["<-"] = "%1(n) <- %2([%3(elements)])"
}

local function connecting()
  --- settings to enable on connect
  view.tab_width  = 2
  view.use_tabs   = false
end

return {
  connecting = connecting,
  snipping   = snipping
}
