--- python extensions
-- @author [Alejandro Baez](https://twitter.com/a_baez)
-- @coypright 2015
-- @license MIT (see LICENSE)
-- @module python

local snipping = {
  true,

  ['def'] = 'def %1(name)(%2(params)):\n\t%3("""\n\t%4\n\t"""\n\t)',
  ['l'] = "lambda %1(param): ",

  -- conditions
  ['if'] = 'if %1(expr):\n\t',
  ['elif'] = 'elif %1(expr):\n\t',
  ['else'] = 'else:\n\t',

  -- loop
  ['forr'] = 'for %1(i)%2(, %3(j)) in range(%4):\n\t',
  ['for'] = 'for %1(i) in %2(iter):\n\t',
  ['while'] = 'while %1(expr):\n\t',
  ['with'] = 'with open(%1(filename)) as %2(f):\n\t',

  -- exceptions
  ['try'] = 'try:\n\t',
  ['except'] = 'except %1(class):\n\t',
  ['finally'] = 'finally:\n\t',
  ['raise'] = 'raise %1(exception)',

  -- others
  lc = "[%0(%1) for %1(i) in %2(iterator) %3(if %4(expr))]",
}

local function connecting()
  --- settings to enable on connect
  view.tab_width  = 4
  view.use_tabs   = false
  view.edge_column  = 79
end

return {
  connecting = connecting,
  snipping   = snipping
}
