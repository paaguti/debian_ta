--- extends go.
-- @author [Alejandro Baez](https://twitter.com/a_baez)
-- @coypright 2015
-- @license MIT (see LICENSE)
-- @module go

local snipping = {
  true,

  const = 'const %1(name) %2(type)  = %3(value)',

  -- functions
  fn = 'func %1(name)(%2(arguments))%3( (%4(results))) {%0}',
  fna = 'func(%1(arguments))%2( (%3(results))) {%0}',
  fnp = 'func (%1(*T)) %2(name)(%3(arguments))%4( (%5(results))) {%0}',

  imp = 'import %1((\n\t"%2(package)"))',
  pkg = 'package %1(main)',
  var = 'var %1(name) %2(type) %3( = %4(value))',

  -- type calls
  ["type"] = 'type %1(Name) %2(struct) {%0}',

  -- conditionals
  ["for"] = "for %1(name) := %2(0); %1 %3(<) %4(10); %1%5(++) {%0}",
  ["forw"] = "for %1(name) %2(<) %3(condition) {%0}",
  ["forr"] = "for %1(name), %2(tmp) := range %4(s_m) {%0}",

  -- if block
  ["if"] = "if %1(statement) {%0}",
  ["ife"] = "if %1(statement) {%2(body)} else %3({%0})",
  ["else"] = "else {%0}",
  ["switch"] = "switch %1(statement) {\n%2\ndefault:\n\t}",
  ["case"] = "case %1(name):\n\t%2(block)",

  -- random
  ['select'] = "select {%0}",
  ["{"] = "{\n\t%0\n",
  ["{}"] = "{\n\t%0\n}",
}

local function connecting()
  view.use_tabs = true
  view.tab_width = 4
end

return {
  connecting = connecting,
  snipping   = snipping
}
