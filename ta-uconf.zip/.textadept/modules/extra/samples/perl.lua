--- perl extensions
-- @author [Alejandro Baez](https://twitter.com/a_baez)
-- @coypright 2015
-- @license MIT (see LICENSE)
-- @module perl

local snipping = {
  true,

  sub = 'sub %1(name)%2((%3(postprocessors))) {%0}',

  -- random
  ['print'] = 'print "%1\\n";',
  ["{}"] = "{\n\t%0\n}",
  ["{"] = "{\n\t%0\n",

  -- conditional
  ['for'] = 'for (%1($i) = %2(0); %1 %3(<) %4(10); %5(%1++)) {%0}',
  ['fore'] = 'foreach %1($_) (%2(@_)) {%0}',
  ['while'] = 'while (%1(expr)) {%0}',
  ['unless'] = 'unless (%1(expr)) {%0}',


  -- if
  ['if'] = 'if (%1(expr)) {%1(body)} %0',
  ['elsif'] = 'elsif (%1(expr)) {%2(body)} %0',
  ['else'] = 'else {%0}',
}

local function connecting()
  --- settings to enable on connect
  view.tab_width  = 4
  view.use_tabs   = false
end

return {
  connecting = connecting,
  snipping   = snipping
}
