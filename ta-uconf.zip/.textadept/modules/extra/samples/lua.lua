--- lua extensions
-- @author [Alejandro Baez](https://twitter.com/a_baez)
-- @coypright 2015
-- @license MIT (see LICENSE)
-- @module lua

local snipping = {
  true,

  -- loops
  ["f"] = "%1{for,fori,forp}",
  fori = "for %1(k) in %2(iterator) do",
  forp = "for %1(k), %2(v) in %3(i)pairs(%4(table)) do",
  ["for"] = "for %1(i) = %2(1), %3(10)%4(, -1) do",
  ["while"] = "while %1(exp) do",
  ["repeat"] = "repeat\n\t%0\nuntil %1(exp) end",
  ["do"] = "do\n\t%0\nend",

  -- functions
  ["fn"] = "function %1(name)(%2(param)) %3(return)end",
  ["function"] = "function %1(name)(%2(param)) %3(return)end",
  ["return"] = "\n\treturn %0\n",

  -- Miscelenious
  ["local"] = "local %1(x) = %2(value)",
  ["--"] = "--[[\n\t%0\n--]]",
  ["---"] = "---[[ %1(name)\n%0\n--]]",
  ["bd"] = "%1(describe)(\"%2(event)\", %3(function))",
  ["call"] = '%1(name)("%2(event)", %3(function))',
  ["r"] = 'require("%1(module)")',

  -- if statement
  ["if"] = "if %1(condition) then",
  ["elseif"] = "elseif %1(condition) then",
  ["else"] = "else\n\t%0\nend",
  ["then"] = "then\n\t%1(body)\n%2{end,else,elseif}"
}

local function connecting()
  --- settings to enable on connect
  view.tab_width  = 3
  view.use_tabs   = false
end

return {
  connecting = connecting,
  snipping = nil
}
