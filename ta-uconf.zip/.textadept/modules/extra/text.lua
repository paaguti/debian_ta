--- lua extensions
-- @module latex
--

common = require("common")

local snipping = {
   -- true,
}

local binding = {
   ['('] = function() return common.enclose_keys('(', ')') end,
   ['['] = function() return common.enclose_keys('[', ']') end,
   ['"'] = function() return common.enclose_keys('"', '"') end,
}

local function connecting()
	common.key_pairing(false,  '{',  '}')
	common.key_pairing(false,  '[',  ']')
	common.key_pairing(true,  '(',  ')')
	common.key_pairing(true,  '"',  '"')
	common.key_pairing(false, '\'', '\'')
end

return {
   binding    = binding,
	connecting = connecting,
	-- snipping   = snipping,
}
