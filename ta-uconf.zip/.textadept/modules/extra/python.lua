common = require("common")
snip = require("snip")

function short_option(txt)
  suffix=string.sub(txt,1,3)
  if suffix == "no-" then
    short=string.upper(string.sub(txt,4,4))
  else
    short=string.sub(txt,1,1)
  end
  return '-'..short
end

function varname(txt)
  suffix=string.sub(txt,1,3)
  if suffix == "no-" then
    return string.sub(txt,4)
  else
    return txt
  end
end

function store_type(txt)
  if string.sub(txt,1,3) == "no-" then
    return "false"
  else
    return "true"
  end
end


local function connecting()
   common.key_pairing(false, '<',  '>')
   common.key_pairing(true,  '{',  '}')
   common.key_pairing(true,  '[',  ']')
   common.key_pairing(true,  '(',  ')')
   common.key_pairing(true,  '"',  '"')
   common.key_pairing(true,  '\'', '\'')
   common.key_pairing(false, '`', '`')
end

local snipping = {
   -- true,

   ['env'] = [[#!/usr/bin/%1(env )python3
# -*- coding: utf-8 -*-
]],
   ['utf8'] = "# -*- coding: utf-8 -*-",
   -- ['ffip'] = 'from __future__ import print_function\n%0',
   -- ['ffiw'] = 'from __future__ import with_statement\n%0',

   ['impas'] = 'from %1(class) import %2(obj)%2( as %3)\n%0',

   ['prt'] = 'print %(\'%1(msg)\'%2%3(, file=%4(sys.std%5(out))))',
   ['def'] = 'def %1(method)%(%2(self, )%3(arg)):',

   ['exc'] = 'except %1(Type)Error%2( as %3(err)):\n\t%0',

   ['sout'] = 'sys.stdout',
   ['serr'] = 'sys.stderr',
   ['sysex'] = 'raise SystemExit',

   ['lbdf'] = '%1(function)%1<snip.ifnotempty(text," = ")>lambda %2(x): %2',
   ['lbdk'] = '%1(key)%1<snip.ifnotempty(text," : ")>lambda %2(x): %2',

   ['argfile'] = 'argparse.FileType(\'%2(r)\')',

   ['with'] = 'with %1(function) as %2(var):\n\t',
   ['sfmt'] ='\'%1(str)\'.format%(%2(vars))',
}

local binding = {
   ['(']   = function() return common.enclose_keys('(',  ')') end,
   ['[']   = function() return common.enclose_keys('[',  ']') end,
   ['{']   = function() return common.enclose_keys('{',  '}') end,
   ['"']   = function() return common.enclose_keys('"',  '"') end,
   ['\'']  = function() return common.enclose_keys('\'', '\'') end,
}

return {
   connecting = connecting,
   snipping   = snipping,
   binding    = binding
}
