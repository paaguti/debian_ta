--- the initializer for extend module.
-- Adds a number of snippets and extensions to different languages.
-- @author [Alejandro Baez](https://twitter.com/a_baez)
--
-- Add key bindings
-- @author [Pedro A. Aranda](mailto:paaguti@gmail.com)
--
-- Adapt snippets handling to textadept 11.0
-- @author [Pedro A. Aranda](mailto:paaguti@gmail.com)
--
local M = {}
for filename in lfs.dir(_USERHOME..'/modules/extra/') do
   if filename:find('%.lua$') and filename ~= 'init.lua' then
      -- using the name of the module as the key. ;)
      local key = filename:match('^(.+)%.lua$')
      M[key] = require('extra.'..key)
   end
end

events.connect(events.LEXER_LOADED, function(lang)
   if M[lang] ~= nil then
      if M[lang].connecting ~= nil then
         M[lang].connecting()
      end

      if M[lang].configured ~=nil and M[lang].configured then return end

      if type(snippets) == 'table' and M[lang].snipping ~= nil then
         for key,val in pairs(M[lang].snipping) do
            --
            -- don't overwrite existing snippets
            --
            if snippets[key] == nil then
               snippets[key] = val
            end
         end
      end

      if type(keys) == 'table' and M[lang].binding ~= nil then
         if keys[lang] == nil or keys[lang] ~= M[lang].binding then
            keys[lang] = M[lang].binding
         end
         --print (keys[lang])
      end
      M[lang].configured = true
   end
end)

return {}
