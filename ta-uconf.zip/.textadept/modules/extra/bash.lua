--- lua extensions
-- @module bash
--

common = require("common")

local function connecting()
   common.key_pairing(false, '<',  '>')
   common.key_pairing(true, '{',  '}')
   common.key_pairing(true, '[',  ']')
   common.key_pairing(true,  '(',  ')')
   common.key_pairing(true,  '"',  '"')
   common.key_pairing(true,  '`',  '`')
   common.key_pairing(true,  '\'', '\'')
end

---
-- Key bindings
--
local binding= {
   ['{']  = function() return common.enclose_keys('{', '}') end,
   ['[']  = function() return common.enclose_keys('[', ']') end,
   ['(']  = function() return common.enclose_keys('(', ')') end,
   ['"']  = function() return common.enclose_keys('"', '"') end,
   ['`']  = function() return common.enclose_keys('`', '`') end,
   ['\''] = function() return common.enclose_keys('\'', '\'') end
}

---
-- Snippets.
--
local snipping = {
   -- true,
   bash = '#!/bin/bash',
   fn = 'function %1(fnc) %() {\n\t%0\n}\n',
}

return {
	connecting = connecting,
	snipping   = snipping,
	binding    = binding
}
