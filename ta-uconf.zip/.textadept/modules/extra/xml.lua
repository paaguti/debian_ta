--- lua extensions
-- @module lua
--

common = require("common")

local binding = {
   ['<']   = function() return common.enclose_keys('<', '>') end,
   ['"']   = function() return common.enclose_keys('"', '"') end,
}

local function connecting()
	common.key_pairing(true,  '<',  '>')
	common.key_pairing(true,  '"',  '"')
	common.key_pairing(false, '{',  '}')
	common.key_pairing(false, '[',  ']')
	common.key_pairing(false, '(',  ')')
	common.key_pairing(false, '\'', '\'')
   common.key_pairing(false, '`', '`')
end

local snipping = {
	-- true,
   at   = '%1(name)="%2(value)"',
   x    = '<%1(tag)>%2(val)%1<text:gsub("^(%w*)%W*.*$","<%1/>")>',
   xn   = '<%1(tag)/>',
--
-- snippets for RFC editing
--
	list = [[<list style=%1(numbers)>
  %0
</list>]],
	xref = '<xref target=\'%1(mark)\' />%0',
	xrfc = '<xref target=\'RFC%1\'>RFC %1(rfc)</xref>%0',
	eref = '<eref target=\'%1(URL)\'>%2(Title)</eref>%0',
	entid = [[<!ENTITY I-D.%1(idref) SYSTEM
"http://xml.resource.org/public/rfc/bibxml3/reference.I-D.%1.xml">
%0]],
	fig = [[<figure anchor="fig:%1(anchor)" title="%2(title)" >
<artwork><![CDATA[
%0
%<string.rep("]", 2)>></artwork>
</figure>
]],
	xslt = '<?xml-stylesheet type=\'text/xsl\' href=\'http://xml.resource.org/authoring/rfc2629.xslt\' ?>',
	xt = '<t>%0</t>',
}

return {
   binding    = binding,
	connecting = connecting,
	snipping   = snipping,
}
