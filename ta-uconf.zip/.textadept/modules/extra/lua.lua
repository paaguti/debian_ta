common = require("common")

local function connecting()
   common.key_pairing(false, '<',  '>')
   common.key_pairing(true,  '{',  '}')
   common.key_pairing(true,  '[',  ']')
   common.key_pairing(true,  '(',  ')')
   common.key_pairing(true,  '"',  '"')
   common.key_pairing(true,  '\'', '\'')
   common.key_pairing(false, '`', '`')
end

local keys = {
   ['{']  = function() return common.enclose_keys('{',  '}') end,
   ['(']  = function() return common.enclose_keys('(',  ')') end,
   ['[']  = function() return common.enclose_keys('[',  ']') end,
   ['"']  = function() return common.enclose_keys('"',  '"') end,
   ['\''] = function() return common.enclose_keys('\'', '\'') end,
}

return {
   connecting = connecting,
   snipping = nil,
   binding = keys,
}

