-- Copyright 2016 Pedro A. Aranda. See Textadept LICENSE.

local M = {}

--[[ This comment is for LuaDoc.
---
-- A module module with utility functions for snippets
--  ifequal, ifempty, ifnotempty
--  varname
--  today
--  file_no_ext

module('_M.snippets')]]

function M.ifequal(txt1,txt2,ok,ko)
  if txt1 == txt2 then
    return ok
  else
    return ko
  end
end

function M.ifnotempty(txt,val1,val2)
  if txt and string.len(txt) > 0 then
    return val1
  else
    return val2 and val2 or ""
  end
end

function M.ifempty(txt,val1,val2)
  if txt and string.len(txt) > 0 then
    return val2 and val2 or ""
  else
    return val1
  end
end

function M.ifdefault(txt, defv, val1, val2)
   if txt and string.len(txt) > 0 and txt ~= defv then
      return val2 and val2 or ""
   else
      return val1
   end
end
--
-- Returns deCamelized and optionally removes the leading underscore
-- in a variable name
--   Camel -> camel
--   _underScore -> underScore
-- used in getter and setter snippets

function M.varname(txt)
  local m = string.match(txt,"^[_A-Z]")
  -- ui.statusbar_text = string.format("m='%s'",m)
  if m=="_" then
    return string.sub(txt,2)
  end
  return string.lower(txt)
end

--
-- get the filename without extension
--
function M.file_no_ext(fspec)
  matcher = WIN32 and "^(.*)(%.[^.\\]+)$" or "^(.*)(%.[^./]+)$"
  fname,ext=string.match(fspec or "",matcher)

  return fname
end

--
-- get the filename without extension
--
function M.basename(fspec)
  fpattern =  WIN32 and "^(.*[\\:/])([^\\:/]+)$" or "^(.*/)([^/]+)$"
  fname,ext=string.match(fspec or "", fpattern)

  return fname
end

--
-- get the filename without extension
--
function M.dirname(fspec)
  fpattern =  WIN32 and "^(.*[\\:])([^\\:]+)$" or "^(.*/)([^/]+)$"
  dname, fname=string.match(fspec or "", fpattern)

  return dname or ""
end

function M.first(txt)
   if txt then
      result = string.sub(txt,1,1)
      return string.find(txt, '-') and string.upper(result) or result
   else
      return ''
   end
end
--
-- Utility functions
-- print a table with it's name
function M.print_table(tab,name)
  print(name)
  for key,value in pairs(tab) do print(key,value) end
end
return M
