-- Copyright 2016 Pedro A. Aranda. See Textadept LICENSE.

local M = {}

--[[ This comment is for LuaDoc.
---
-- My common module
-- Utility funcions for editing
--  enclose_keys

module('_M.common')]]

--
-- Keymap related functions
--

function M.key_pairing(enable, op, cl)
  --
  -- enable or disable key pairing for op and cl
  --
  textadept.editing.auto_pairs    [string.byte(op)] = enable and cl or nil
  textadept.editing.brace_matches [string.byte(op)] = enable and 1  or nil
  textadept.editing.brace_matches [string.byte(cl)] = enable and 1  or nil
  textadept.editing.typeover_chars[string.byte(cl)] = enable and 1  or nil
end

function M.enclose_keys(op,cl)
  --
  -- enclose selected text between open and close
  -- or do the default action for the pressed key
  --
  ui.statusbar_text = "In common.enclose_keys()"
  if view.selection_empty then
	  return false -- default action
  else
	  textadept.editing.enclose(op, cl)
	  return true -- prevent default
  end
end

function M.today(spec)
   -- default timespec is  year="%Y" month="%B" day="%d"
   -- like in RFCs
   local sysloc = os.setlocale(nil)
   os.setlocale("C")
   local now=os.date(spec or 'year="%Y" month="%B" day="%d"')
   os.setlocale(sysloc)
   return now
end

function M.insert_date(spec)
   --   default timespec is  "%A, %d %B %Y"
   --   insert_date() like in
   --   Last visit: ... comments in bibtex files
   view:replace_sel(M.today(spec or "%A, %d %B %Y"))
   return true -- don't do anything else
end

--
-- Utility functions
-- print a table with it's name
function M.print_table(tab,name)
  print(name)
  for key,value in pairs(tab) do print(key,value) end
end
return M
